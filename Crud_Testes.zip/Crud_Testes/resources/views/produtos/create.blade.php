@extends('crud_template')

@section('content')
<div class="card">
    <div class="card-header">
       <h2>Cadastro de Veículos</h2> 
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col">
                @if ($errors->any())
                    <div class="alert alert-danger">
                        <strong>Problemas com seus dados:</strong>
                        <br>
                        @foreach($errors->all() as $error)
                            <li> {{ $error }}</li>
                        @endforeach
                    </div>
                @endif
            </div>
        </div>

        <div class="row">
            <form action="{{ url('produtos/novo') }}" method="POST">
                @csrf
                <div class="row">
                    <strong>Descrição:</strong>
                    <input placeholder="Digite a descrição" class="form-control mb-3" name="descrição" type="text" />
                    <strong>Referência</strong>
                    <input placeholder="Digite a referência" class="form-control mb-3" name="referência" type="number" />
                    <strong>Categoria:</strong>
                    <input placeholder="Digite a categoria" class="form-control mb-3" name="categoria" type="text" />

                    <div class="col">
                        <a class="btn btn-secondary" href="{{ url('/produtos') }}">Voltar</a>
                    </div>
                    <div class="col">
                        <button class="btn btn-primary" type="submit">Salvar</button>
                    </div>

                </div>
            </form>
        </div>
    </div>
</div>
@endsection