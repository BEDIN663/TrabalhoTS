@extends('crud_template')

@section('content')
<div class="card">
    <div class="card-header">
       <h2>Cadastro de fornecedores</h2> 
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col">
                @if ($errors->any())
                    <div class="alert alert-danger">
                        <strong>Problemas com seus dados:</strong>
                        <br>
                        @foreach($errors->all() as $error)
                            <li> {{ $error }}</li>
                        @endforeach
                    </div>
                @endif
            </div>
        </div>

        <div class="row">
            <form action="{{ url('fornecedor/novo') }}" method="POST">
                @csrf
                <div class="row">
                    <strong>Razão Social:</strong>
                    <input placeholder="Digite a razão social" class="form-control mb-3" name="razãosocial" type="text" />
                    <strong>Endereço:</strong>
                    <input placeholder="Digite o endereço" class="form-control mb-3" name="endereço" type="text" />
                    <strong>Cidade:</strong>
                    <input placeholder="Digite a cidade" class="form-control mb-3" name="cidade" type="text" />
                    <strong>Estado:</strong>
                    <input placeholder="Digite o estado" class="form-control mb-3" name="estado" type="text" />
                    <strong>Cep:</strong>
                    <input placeholder="Digite o cep" class="form-control mb-3" name="cep" type="text" />

                    <div class="col">
                        <a class="btn btn-secondary" href="{{ url('/fornecedor') }}">Voltar</a>
                    </div>
                    <div class="col">
                        <button class="btn btn-primary" type="submit">Salvar</button>
                    </div>

                </div>
            </form>
        </div>
    </div>
</div>
@endsection