<?php

namespace Tests\Feature;

use App\Models\Produto;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class ProdutoTeste extends TestCase
{
    use RefreshDatabase;
    public function test_admin_can_store_new_product()
    {
        $admin = User::factory()->create(['is_admin' => 1]);
        $response = $this->actingAs($admin)->post('/produto', [
            'descrição' => 'Branco Supremo',
            'referência' => '100',
            'categoria' => Chapa_Mdf
        ]);
        // dd($response->getContent());
        $response->assertSessionHasNoErrors();
        $response->assertRedirect('/produto');
        $this->assertCount(1, Produto::all());
        $this->assertDatabaseHas('produto', ['descrição' => 'Branco Supremo', 'referência' => '100', 'categoria' => Chapa_Mdf]);
    }

     public function test_admin_can_see_the_edit_product_page()
    {
         $admin = User::factory()->create(['is_admin' => 1]);
         $product = Produto::factory()->create();
         $response = $this->actingAs($admin)->get('/produto/' . $produto->id . '/edit');
         $response->assertStatus(200);
         $response->assertSee($produto->descrição);
     }

     public function test_admin_can_update_product()
     {
         $admin = User::factory()->create(['is_admin' => 1]);
         Produto::factory()->create();
         $this->assertCount(1, Produto::all());
         $product = Produto::first();
         $response = $this->actingAs($admin)->put('/produto/' . $produto->id, [
             'descrição'  => 'Updated Product',
             'referência' => 'Test',
             'categoria' => 5
         ]);
         $response->assertSessionHasNoErrors();
         $response->assertRedirect('/produto');
         $this->assertEquals('Updated Product', Produto::first()->descrição);
         $this->assertEquals('Test', Produto::first()->referência);
        $this->assertEquals(5, Produto::first()->categoria);
     }

     public function test_admin_can_delete_product()
     {
        $admin = User::factory()->create(['is_admin' => 1]);
        $produto =  Produto::factory()->create();
        $this->assertEquals(1, Produto::count());
         $response = $this->actingAs($admin)->delete('/produto/' . $produto->id);
         $response->assertStatus(302);
         $this->assertEquals(0, Produto::count());
     }

     public function test_auth_user_can_access_dashboard()
     {
         $user = User::factory()->create();
  
         $response = $this->actingAs($user)->get('/produto');
  
         $response->assertStatus(200);
     }

     public function test_unath_user_cannot_access_dashboard()
     {
         $response = $this->get('/welcome');
         $response->assertStatus(200);
         $response->assertRedirect('/login');
     }
  
}
