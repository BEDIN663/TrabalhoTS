<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Models\Produto;
use Illuminate\Support\Facades\DB;

class ProdutosController extends Controller
{
    public function index() {

        $produtos = DB::table('produtos')->orderBy('descrição', 'asc')->get();
        $produtos = json_decode($produtos, true);
        return view('produtos.index', 
        ['produtos' => $produtos]); //select * from produtos
    }
    
    //função que irá retornar a tela do form
    public function create() {
        return view("produtos.create");
    }

    public function store(Request $request) {
        //dd($request->all());

        $request->validate([
            'descrição' => 'required|min:2|max:50',
            'referência' => 'required|min:2|max:50',
        ]);
        
        Produto::create([
            'descrição' => $request->descrição,
            'referência' => $request->referência,
            'categoria' => $request->categoria,
            
        ]);
        return redirect('/produtos')->with('success', 'Produto salvo com sucesso!');
    }

    public function edit($id)
    {
        $produtos = Produto::find($id);
        return view('produtos.edit', ['produto' => $produtos]);
    }
    public function update(Request $request)
    {
        $produtos = Produto::find($request->id);
        $produtos->update([
            'descrição' => $request->descrição,
            'referência' => $request->referência,
            'categoria' => $request->categoria
        ]);
        return redirect('/produtos');
    }

    public function destroy($id)
    {
        $produtos = Produto::find($id);
        $produtos->delete();
        return redirect('/produtos');
    }
}
